#include "stdlib.h"

void HariMain(void)
{
	printf("hello, world : %s %d\n", "aaa", 10);
	exit(0);
}
